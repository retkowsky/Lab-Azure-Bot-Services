// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { GreetingDialog } = require('./greeting');

module.exports.GreetingDialog = GreetingDialog;
